import React, { useState } from 'react';
import ShareGate from './ShareGate';

const SEGMENTS = [
    { label: "TRY AGAIN", color: "#334155", image: "https://img.icons8.com/3d-fluency/94/sad.png" },
    { label: "Rs. 5,000", color: "#fbbf24", image: "https://img.icons8.com/3d-fluency/94/money-bag.png" },
    { label: "iPhone 15", color: "#dc2626", image: "https://img.icons8.com/3d-fluency/94/iphone-14-pro.png" },
    { label: "TRY AGAIN", color: "#334155", image: "https://img.icons8.com/3d-fluency/94/sad.png" },
    { label: "50 GB Data", color: "#2563eb", image: "https://img.icons8.com/3d-fluency/94/wi-fi-connected.png" },
    { label: "GIFT BOX", color: "#9333ea", image: "https://img.icons8.com/3d-fluency/94/gift.png" },
];

const SpinWheel: React.FC = () => {
    const [spinning, setSpinning] = useState(false);
    const [rotation, setRotation] = useState(0);
    const [attempts, setAttempts] = useState(0);
    const [prize, setPrize] = useState<string | null>(null);
    const [showForm, setShowForm] = useState(false);
    const [formUnlocked, setFormUnlocked] = useState(false);
    const [submissionState, setSubmissionState] = useState<'idle' | 'clicked_1' | 'clicked_2' | 'submitted'>('idle');

    const spin = () => {
        if (spinning || attempts >= 3) return;

        setSpinning(true);
        setPrize(null);

        // Rigged Logic:
        // Attempt 1: Land on "Try Again" (Segment 0)
        // Attempt 2: Land on "Rs 5000" (Segment 1)
        // Attempt 3: Land on "iPhone 15" (Segment 2)
        
        let targetSegmentIndex = 0;
        if (attempts === 0) targetSegmentIndex = 0; // Try Again
        if (attempts === 1) targetSegmentIndex = 1; // Rs 5000
        if (attempts === 2) targetSegmentIndex = 2; // iPhone

        // Calculate rotation
        // Each segment is 60 degrees (360 / 6)
        // To land on index i, we need to rotate so that index i is at the top (pointer).
        // Default pointer is usually at 0 deg (top).
        // We add extra full spins (360 * 5) for effect.
        
        const segmentAngle = 360 / SEGMENTS.length;
        const offset = 360 - (targetSegmentIndex * segmentAngle); 
        const randomOffset = Math.random() * 10 - 5; // Slight randomness within segment
        const newRotation = rotation + (360 * 8) + offset + randomOffset;

        setRotation(newRotation);

        setTimeout(() => {
            setSpinning(false);
            setAttempts(prev => prev + 1);
            setPrize(SEGMENTS[targetSegmentIndex].label);
            
            if (attempts === 2) {
                // Final win
                setTimeout(() => setShowForm(true), 1000);
            }
        }, 4000); // 4s animation
    };

    const handleFormSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        
        // Fake Adsterra Logic as requested by user tactics
        // 1st click: Open Ad 1
        // 2nd click: Open Ad 2
        // 3rd click: Submit
        
        const adLink = "https://google.com"; // Placeholder for ad link

        if (submissionState === 'idle') {
            window.open(adLink, '_blank');
            setSubmissionState('clicked_1');
        } else if (submissionState === 'clicked_1') {
            window.open(adLink, '_blank');
            setSubmissionState('clicked_2');
        } else {
            setSubmissionState('submitted');
            alert("සාර්ථකයි! (Successfully Submitted)");
        }
    };

    return (
        <div className="flex flex-col items-center justify-center p-4">
            <h2 className="text-3xl font-bold text-amber-400 mb-2 sinhala-text text-center shadow-amber-500/50 drop-shadow-lg">
                අවුරුදු වාසනාව (New Year Fortune)
            </h2>
            
            {/* Prize Banner */}
            <div className="bg-gradient-to-r from-red-600 via-amber-500 to-red-600 text-white px-8 py-2 rounded-full font-black text-lg mb-8 animate-pulse shadow-[0_0_20px_rgba(251,191,36,0.5)] border-2 border-yellow-300 transform hover:scale-105 transition-transform text-center">
                🏆 WIN: iPhone 15 & Rs. 5000!
            </div>

            <div className="relative w-80 h-80 md:w-96 md:h-96">
                {/* Pointer */}
                <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-4 z-20 w-8 h-10">
                   <div className="w-0 h-0 border-l-[15px] border-l-transparent border-r-[15px] border-r-transparent border-t-[30px] border-t-white drop-shadow-md"></div>
                </div>

                {/* Wheel */}
                <div 
                    className="w-full h-full rounded-full border-4 border-amber-500 shadow-[0_0_30px_rgba(245,158,11,0.5)] overflow-hidden relative wheel-spin"
                    style={{ transform: `rotate(${rotation}deg)` }}
                >
                    {/* Background Colors */}
                     <div 
                        className="absolute inset-0 rounded-full"
                        style={{
                            background: `conic-gradient(
                                ${SEGMENTS.map((s, i) => `${s.color} ${i * (360/6)}deg ${(i+1) * (360/6)}deg`).join(', ')}
                            )`
                        }}
                     />
                     
                     {/* Images Layer */}
                     {SEGMENTS.map((seg, i) => (
                         <div 
                            key={i}
                            className="absolute top-1/2 left-1/2 w-full h-0 flex justify-end items-center origin-left z-10"
                            style={{ transform: `rotate(${i * 60 + 30}deg) translate(0, 0)` }} // +30 to center in segment
                         >
                            <div className="mr-4 md:mr-8 transform rotate-90 flex flex-col items-center justify-center text-white w-24">
                                <span className="text-sm md:text-base font-black uppercase tracking-wider text-center drop-shadow-[0_2px_2px_rgba(0,0,0,0.8)] leading-tight w-28 break-words">
                                    {seg.label}
                                </span>
                                <img 
                                    src={seg.image} 
                                    alt={seg.label}
                                    className="w-8 h-8 md:w-12 md:h-12 object-contain drop-shadow-lg mt-1"
                                />
                            </div>
                         </div>
                     ))}
                </div>
                
                {/* Center Cap */}
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-14 h-14 bg-white rounded-full z-10 shadow-[0_0_15px_rgba(0,0,0,0.5)] flex items-center justify-center border-2 border-amber-100">
                    <div className="w-10 h-10 bg-gradient-to-br from-amber-400 to-amber-600 rounded-full animate-pulse shadow-inner" />
                </div>
            </div>

            <button 
                onClick={spin}
                disabled={spinning || attempts >= 3}
                className="mt-8 px-12 py-4 bg-gradient-to-r from-amber-500 to-red-600 rounded-full text-2xl font-bold text-white shadow-xl hover:scale-105 active:scale-95 transition-transform disabled:opacity-50 disabled:grayscale border-2 border-white/20"
            >
                {spinning ? "Spinning..." : attempts >= 3 ? "No More Spins" : "SPIN NOW"}
            </button>

            {prize && !spinning && (
                <div className="mt-4 p-4 bg-white/10 rounded-lg text-center backdrop-blur-sm animate-bounce border border-white/10">
                    <p className="text-gray-200 text-sm">You won:</p>
                    <p className="text-2xl font-bold text-amber-400 drop-shadow-md">{prize}</p>
                </div>
            )}

            {showForm && (
                <div className="mt-10 w-full max-w-lg animate-in fade-in slide-in-from-bottom-10 duration-700">
                    <div className="bg-gradient-to-b from-slate-800 to-slate-900 border border-amber-500 rounded-2xl p-6 shadow-2xl relative overflow-hidden">
                        {/* Confetti effect background */}
                        <div className="absolute inset-0 opacity-10 pointer-events-none bg-[url('https://www.transparenttextures.com/patterns/stardust.png')]"></div>
                        
                        <h3 className="text-2xl font-bold text-center text-white mb-2 relative z-10">
                            🎉 CONGRATULATIONS!
                        </h3>
                        <p className="text-center text-gray-400 mb-6 relative z-10">
                            You have won an <span className="text-amber-400 font-bold">iPhone 15</span>!
                        </p>

                        {!formUnlocked ? (
                            <ShareGate onComplete={() => setFormUnlocked(true)} />
                        ) : (
                            <form onSubmit={handleFormSubmit} className="space-y-4 mt-6 relative z-10">
                                <div>
                                    <label className="block text-sm text-gray-400 mb-1">Full Name</label>
                                    <input required type="text" className="w-full bg-slate-800 border border-slate-600 rounded-lg p-3 text-white focus:border-amber-500 outline-none" placeholder="Saman Perera" />
                                </div>
                                <div>
                                    <label className="block text-sm text-gray-400 mb-1">Mobile Number</label>
                                    <input required type="tel" className="w-full bg-slate-800 border border-slate-600 rounded-lg p-3 text-white focus:border-amber-500 outline-none" placeholder="077 123 4567" />
                                </div>
                                <div>
                                    <label className="block text-sm text-gray-400 mb-1">Delivery Address</label>
                                    <textarea required className="w-full bg-slate-800 border border-slate-600 rounded-lg p-3 text-white focus:border-amber-500 outline-none" rows={3} placeholder="No 123, Galle Road, Colombo"></textarea>
                                </div>
                                
                                <button 
                                    type="submit"
                                    className="w-full py-4 bg-gradient-to-r from-green-500 to-emerald-700 rounded-lg font-bold text-white text-lg shadow-lg hover:brightness-110 transition-all"
                                >
                                    {submissionState === 'submitted' ? "Submission Received!" : "CLAIM PRIZE"}
                                </button>
                                {submissionState !== 'submitted' && submissionState !== 'idle' && (
                                    <p className="text-xs text-center text-red-400 bg-red-900/20 p-2 rounded mt-2">
                                        Human verification required: Please click the button again to confirm.
                                    </p>
                                )}
                            </form>
                        )}
                    </div>
                </div>
            )}
        </div>
    );
};

export default SpinWheel;